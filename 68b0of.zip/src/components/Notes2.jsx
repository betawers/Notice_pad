import React from "react";

function Notes2() {
  return (  
    <div className= "note">
       <h1>This the the first activity for the GDSC_JDCOEM</h1>
       <p> 
          All the core committee is suppose to make a small project for the contribution to DSC's Repositary.
          </p>
  </div>
  );
 
}

export default Notes2;
