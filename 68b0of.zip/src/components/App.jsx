import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Notes1 from "./Notes1";
import Notes2 from "./Notes2";
function App() {
  return (  
  <div>
  <Header />
  <Notes1 />
  <Notes2 />
  <Footer />
</div>
  )
 
}

export default App;
