import React from "react";

function Header() {
  return <h1>Hello Shaurya Sinha!</h1>;
}

export default Headers;
